/*
(c) 2012 Fengtao Fan
*/
#ifndef _GI_COMPLEX_H_
#define _GI_COMPLEX_H_
#include "SimpleGraph.h"
#include "SimplexNodeGIC.h"
#include "SimplicialComplexGIC.h"

#include <vector>
#include <set>
#include <map>
#include <algorithm>

//class GIComplex : public SimplicialTree<SimpleGraph>
//{
//public:
//	GIComplex()
//	{
//    };
//
//    GIComplex(const int in_dim, const int v_number, SimpleGraph *inDataPtr) : SimplicialTree(in_dim, v_number, inDataPtr) {
//    }
//    bool Construction(); //virtual
//};

#endif //_GI_COMPLEX_H_
