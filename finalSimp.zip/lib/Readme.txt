Please rename "ANN32" to "ANN32.lib" and "ANN64" to "ANN64.lib".

Depending on the Windows systems,
the lib file "ANN32.lib" should be renamed as "ANN.lib" for building this program on Windows 32bit 
and 
the lib file "ANN64.lib" should be renamed as "ANN.lib" for building this program on Windows 64bit.

'libANN.a' is used for building under Ubuntu.