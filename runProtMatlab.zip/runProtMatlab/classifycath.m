clear all
fid = fopen('cath-domain-list.txt');
tline = fgetl(fid);
label = [];
protname = [];
% protname2 = [];
% protname3 = [];
% protname4 = [];
counter = 0;
train = [];
while(ischar(tline))
    tline = fgetl(fid);
    counter = counter + 1;
    if counter<16
        continue;
    end
    tsk = strsplit(tline,' ');
    buff1 = tsk(1);
    buff2 = buff1{1};
    if(buff2(1) ~= '4')
        continue;
    end
    protname =  [protname tsk(1)];
%     if (tsk(2)=='1')
%         protname1 = [protname1 tsk(1)];
%     elseif (tsk(2)=='2')
%         protname2 = [protname2 tsk(1)];
%     elseif (tsk(2)=='3')
%         protname3 = [protname3 tsk(1)];
%     elseif (tsk(2)=='4')
%         protname4 = [protname4 tsk(1)];
%     end
    label = [label tsk(2)];
end
fid = fopen('text.csv');
tline = fgetl(fid);
numfeature = 18;
one = [];
two = [];
three = [];
four = [];
while(ischar(tline))
    feature = strsplit(tline,',');
    tline = fgetl(fid);
    name = feature(19);
    nameString = name{1};
    k = strmatch(nameString(2:end-10),protname);
    if(isempty(strmatch(nameString(2:end-10),protname))==1)
        display('not found',nameString(2:end-10));
        continue;
    else
        buff = label(k);
       if(buff{1} == '1')
           t = zeros(1,numfeature);
            for i=1:numfeature
                t(1,i) = str2double(feature(i));        
            end
            one = vertcat(one,t);
       elseif(buff{1} == '2')
           t = zeros(1,numfeature);
            for i=1:numfeature
                t(1,i) = str2double(feature(i));        
            end
            two = vertcat(two,t);
       elseif(buff{1} == '3')
           t = zeros(1,numfeature);
            for i=1:numfeature
                t(1,i) = str2double(feature(i));        
            end
            three = vertcat(three,t);
       elseif (buff{1} == '4')
           t = zeros(1,numfeature);
            for i=1:numfeature
                t(1,i) = str2double(feature(i));        
            end
            four = vertcat(four,t);
       end
    end
    
end

train = vertcat(one(1:1365,:),two(1:2254,:),three(1:4443,:));
trainlabel = vertcat(ones(1365,1),ones(2254,1),ones(4443,1)*2);
test = vertcat(one(1366:end,:),two(2255:end,:),three(4444:end,:));
testlabel  = vertcat(ones(341,1),ones(563,1),ones(1110,1)*2);
MdlSVM = fitcecoc(train,trainlabel);
YSVM = predict(MdlSVM,test);
YSVM2 = knnclassify(test,train,trainlabel);
ABC = testlabel - YSVM;
ABC2 = testlabel - YSVM2;
ttt2 = sum(ABC2(:)==0)*100/size(testlabel,1)
ttt = sum(ABC(:)==0)*100/size(testlabel,1)