x = totallabel;
xx = unique(x);       % temp vector of vals
x = sort(x);          % sorted input aligns with temp (lowest to highest)
tesla = zeros(size(xx)); % vector for freqs
% frequency for each value
for i = 1:length(xx)
    tesla(i) = sum(x == xx(i));
end