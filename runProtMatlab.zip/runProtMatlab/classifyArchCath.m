clear all;
fid = fopen('cath-domain-list.txt');
tline = fgetl(fid);
label = [];
protname = [];
% protname2 = [];
% protname3 = [];
% protname4 = [];
counter = 0;
train = [];
while(ischar(tline))
    tline = fgetl(fid);
    counter = counter + 1;
    if counter<16 
        continue;
    end
    if tline==-1
        break;
    end
    tsk = strsplit(tline,' ');
    buff1 = tsk(1);
    buff2 = buff1{1};
    if(buff2(1) ~= '4')
        continue;
    end
    protname =  [protname tsk(1)];
%     if (tsk(2)=='1')
%         protname1 = [protname1 tsk(1)];
%     elseif (tsk(2)=='2')
%         protname2 = [protname2 tsk(1)];
%     elseif (tsk(2)=='3')
%         protname3 = [protname3 tsk(1)];
%     elseif (tsk(2)=='4')
%         protname4 = [protname4 tsk(1)];
%     end
    label = [label tsk(2)];
end
fid = fopen('txts-225-5.csv');
tline = fgetl(fid);
numfeature = 225;
one = [];
two = [];
three = [];
four = [];
total = [];
totallabel = [];
while(ischar(tline))
    feature = strsplit(tline,',');
    tline = fgetl(fid);
    name = feature(numfeature+1);
    nameString = name{1};
    k = strmatch(nameString(4:end-10),protname);
    if(isempty(strmatch(nameString(4:end-9),protname))==1)
        display('not found',nameString(2:end-10));
        continue;
    else
        buff = label(k);
        if(buff{1}=='1')
            t = zeros(1,numfeature);
            for i=1:numfeature
                t(1,i) = str2double(feature(i));        
            end  
            one = vertcat(one,t);
        elseif(buff{1}=='2')
            t = zeros(1,numfeature);
            for i=1:numfeature
                t(1,i) = str2double(feature(i));        
            end             
            two = vertcat(two,t);
        elseif(buff{1}=='3')
            t = zeros(1,numfeature);
            for i=1:numfeature
                t(1,i) = str2double(feature(i));        
            end 
            three = vertcat(three,t);
        elseif(buff{1}=='4')
            t = zeros(1,numfeature);
            for i=1:numfeature
                t(1,i) = str2double(feature(i));        
            end 
            four = vertcat(four,t);
        end
%         total = vertcat(total,t);
%         totallabel = vertcat(totallabel,buff{1});
     end
    
end

train = vertcat(one(1:895,:),two(1:1176,:),three(1:1927,:));
trainlabel = vertcat(ones(895,1),ones(1176,1),ones(1927,1)*0);
test = vertcat(one(896:end,:),two(1177:end,:),three(1928:end,:));
testlabel  = vertcat(ones(224,1),ones(292,1),ones(482,1)*0);
MdlSVM = fitcecoc(train,trainlabel);
YSVM = predict(MdlSVM,test);
ABC = testlabel - YSVM;
ttt = sum(ABC(:)==0)*100/size(testlabel,1)
% YSVM2 = knnclassify(test,train,trainlabel);
% ABC2 = testlabel - YSVM2;

% ttt2 = sum(ABC2(:)==0)*100/size(testlabel,1)
