clear all;
fid = fopen('cath-domain-list.txt');
tline = fgetl(fid);
label = [];
protname = [];
protname2 = [];
% protname3 = [];
% protname4 = [];
counter = 0;
train = [];
while(ischar(tline))
    tline = fgetl(fid);
    counter = counter + 1;
    if counter<16
        continue;
    end
    if tline==-1
        break
    end
    tsk = strsplit(tline,' ');
    buff1 = tsk(1);
    buff2 = buff1{1};
%     if(buff2(1) ~= '4')
%         continue;
%     end
    protname =  [protname tsk(1)];
%     if (tsk(2)=='1')
%         protname1 = [protname1 tsk(1)];
%     elseif (tsk(2)=='2')
%         protname2 = [protname2 tsk(1)];
%     elseif (tsk(2)=='3')
%         protname3 = [protname3 tsk(1)];
%     elseif (tsk(2)=='4')
%         protname4 = [protname4 tsk(1)];
%     end
    label = [label tsk(4)];
end
fid = fopen('txts-250-7.csv');
tline = fgetl(fid);
numfeature = 250;
% one = [];
% two = [];
% three = [];
% four = [];
total = [];
totallabel = [];
while(ischar(tline))
    feature = strsplit(tline,',');
    tline = fgetl(fid);
    name = feature(numfeature+1);
    nameString = name{1};
    k = strmatch(nameString(4:end-9),protname);
    if(isempty(strmatch(nameString(4:end-9),protname))==1)
        display('not found',nameString(2:end-10));
        continue;
    else
        buff = label(k);
        t = zeros(1,numfeature);
        for i=1:numfeature
            t(1,i) = str2double(feature(i));        
        end
        total = vertcat(total,t);
        totallabel = vertcat(totallabel,str2num(buff{1}));
     end
    
end

trainlabel = [];
trainlabel40 = [];
train40 = [];
train0 = [];
[sz,~] = size(total);
trainlabel0 = [];
for i =1:sz
    if(totallabel(i)==1150)
        train40 = vertcat(train40,total(i));
        trainlabel40 = vertcat(trainlabel40,4);
    else
        train0 = vertcat(train0,total(i));
        trainlabel0 = vertcat(trainlabel0,0);
    end
end
[sz40,~] = size(train40);
train = vertcat(train40(1:floor(0.8*sz40),:),train0(1:floor(0.8*sz40),:));
trainlabel = vertcat(ones(floor(0.8*sz40),1),zeros(floor(0.8*sz40),1));
test = vertcat(train40(1:(sz40-floor(0.8*sz40)),:),train0(1:(sz40-floor(0.8*sz40)),:));
ss = sz40-floor(0.8*sz40);
testlabel = vertcat(ones(ss,1),zeros(ss,1));
%vertcat(one(1:1365,:),two(1:2254,:),three(1:4443,:));
% trainlabel = vertcat(ones(1365,1),ones(2254,1),ones(4443,1)*2);
% test = vertcat(one(1366:end,:),two(2255:end,:),three(4444:end,:));
% testlabel  = vertcat(ones(341,1),ones(563,1),ones(1110,1)*2);
 MdlSVM = fitcecoc(train,trainlabel);
 YSVM = predict(MdlSVM,test);
% YSVM2 = knnclassify(test,train,trainlabel);
 ABC = testlabel - YSVM;
% ABC2 = testlabel - YSVM2;
% ttt2 = sum(ABC2(:)==0)*100/size(testlabel,1)
 ttt = sum(ABC(:)==0)*100/size(testlabel,1)